## 多功能shell实现

建议在了解 哥斯拉webshell工具 工作原理及代码，及 wsMemShell 原理及代码后，再阅读下面这篇 Freebuf 文章，获得更好的阅读体验。

Freebuf: [WebSocket webshell 多功能shell实现](https://www.freebuf.com/articles/web/339702.html)

<img src="ws.jpg" alt="ws" width="49%"></a> <img src="ws2.jpg" alt="ws" width="49%"></a>