# TomcatMemShellDemo
A Demo For Testing Tomcat MemShell.

# Include

- Servlet:
  - Filter MemShell
  - Servlet MemShell
  - Listener MemShell
  - Valve MemShell
- jsp:
  - filter_exp.jsp (reflect)
  - filter_exp2.jsp
  - listener_exp.jsp
  - servlet_exp.jsp
  - valve_exp.jsp

# Conference

[https://mp.weixin.qq.com/s/TQsFAjMlYYGRAWW-CwJYJA](https://mp.weixin.qq.com/s/TQsFAjMlYYGRAWW-CwJYJA)

[https://www.cnblogs.com/nice0e3/p/14622879.html#0x00-%E5%89%8D%E8%A8%80](https://www.cnblogs.com/nice0e3/p/14622879.html#0x00-%E5%89%8D%E8%A8%80)

[https://blog.csdn.net/weixin_43263451/article/details/125902345](https://blog.csdn.net/weixin_43263451/article/details/125902345)

[https://www.cnblogs.com/xyylll/p/15463635.html#_label0_3](https://www.cnblogs.com/xyylll/p/15463635.html#_label0_3)