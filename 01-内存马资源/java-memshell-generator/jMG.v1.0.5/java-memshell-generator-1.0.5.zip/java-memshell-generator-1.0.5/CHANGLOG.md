#### 2023-06-09 

- [BUG]  修复"小黑屋"内测功能 bug
- [优化]  添加窗口拉伸支持
- [优化]  添加鼠标右键菜单，复制选中内容/复制全部内容


#### 2023-06-08 GUI 图形化工作模式开发

- 完成 GUI 设计
- 移植插件版功能

<img width="900" alt="image" src="https://github.com/pen4uin/java-memshell-generator/assets/55024146/19ef194c-8ec9-41e6-add6-1ff4671acb34">


#### 2023-06-04 v1.0.4.beta1 社区版首次发布

- 支持的中间件和框架 (Tomcat/Resin/Jetty/WebLogic/WebSphere/Undertow/GlassFish/Spring)
- 支持的网站管理工具 (Behinder/Godzilla/Custom)
- 支持的内存马类型 (Filter/Listener/Interceptor)
- 支持的输出格式 (BASE64/BCEL/CLASS/JS/JSP/JAR/BIGINTEGER)
- 支持的辅助模块 (探测目标中间件/序列化数据封装)


