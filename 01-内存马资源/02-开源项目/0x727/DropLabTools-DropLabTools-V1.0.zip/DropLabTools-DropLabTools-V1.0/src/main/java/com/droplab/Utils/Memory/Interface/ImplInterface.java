package com.droplab.Utils.Memory.Interface;

public interface ImplInterface {
    public String get(Object obj,String type,boolean template);
}
