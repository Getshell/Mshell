package com.droplab.Utils.UnSerialize.Gadget.Interface;

public interface GadgetInterface {
    public byte[] getObject(final Object o);
}
