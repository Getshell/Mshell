package com.droplab.Controller;

import java.util.Map;

public interface BaseController {
    Map<String, String> getMap();
}
