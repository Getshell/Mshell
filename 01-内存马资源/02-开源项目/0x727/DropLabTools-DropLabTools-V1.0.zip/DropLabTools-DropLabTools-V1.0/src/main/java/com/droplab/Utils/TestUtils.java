package com.droplab.Utils;


public class TestUtils {
    public static void main(String[] args) throws Exception {

    }
}
