可使用vulhub中的/php/CVE-2019-11043进行试验。

```
https://github.com/vulhub/vulhub/tree/master/php/CVE-2019-11043
```

