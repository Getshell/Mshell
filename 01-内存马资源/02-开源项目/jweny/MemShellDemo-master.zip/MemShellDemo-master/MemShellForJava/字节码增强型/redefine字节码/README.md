冰蝎3.0-BETA7 内存马为redefine字节码型。

https://github.com/rebeyond/Behinder/releases

https://github.com/MountCloud/BehinderClientSource

