

Example SpringMVC program taken from http://www.mkyong.com/spring3/spring-3-mvc-hello-world-example/
