# tomcat_shell
用[threedr3am](https://github.com/threedr3am)大佬的代码拼成的jsp shell，纯属学习

1.先执行init.jsp

2.再执行shell.jsp

