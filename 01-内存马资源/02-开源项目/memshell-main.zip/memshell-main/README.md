# memshell
简单的内存马代码，比较烂

有tomcat、spring、resin的一些内存马，需要将resin/lib库导入，然后无报错即可

class文件用来打jndi注入
