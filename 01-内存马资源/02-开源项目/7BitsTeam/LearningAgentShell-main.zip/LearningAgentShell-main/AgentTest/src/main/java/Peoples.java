public class Peoples {
    public void say(){
        System.out.println("hello");
    }
}