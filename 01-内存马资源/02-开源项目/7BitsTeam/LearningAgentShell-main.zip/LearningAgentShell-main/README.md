# LearningAgentShell

## 本文是7bits安全团队文章《Java安全-记一次实战使用memoryshell》涉及到的

* ToRun

一个样例程序，通过AgentTest修改正在执行的代码内容

* AgentTest

通过java的Agent与assist技术操作jvm内存达到修改另一个程序内存的效果

* ZhouYu-changed

基于ZhouYu，针对atlassian bitbucket定制的记录密码后门

### 欢迎关注我们的公众号 - Zbits2022

![](/images/qrcode.jpg)


