code = """
    javax.xml.bind.DatatypeConverter.parseHexBinary
"""