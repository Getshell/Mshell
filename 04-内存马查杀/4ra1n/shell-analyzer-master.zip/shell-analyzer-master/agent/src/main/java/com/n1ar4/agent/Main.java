package com.n1ar4.agent;

public class Main {
    public static void main(String[] args) {
        System.out.println("##################################");
        System.out.println("THIS IS AN AGENT");
        System.out.println("DO NOT USE THIS JAR");
        System.out.println("use: java -jar shell-analyzer.jar");
        System.out.println("##################################");
    }
}