## 测试用内存马

这里的 JSP 文件来自其他师傅的 Github 或文章，这里用于测试

注意：
- servlet.jsp 需要执行两次才可以成功注入
- 测试环境为 Java 8 / Tomcat 9